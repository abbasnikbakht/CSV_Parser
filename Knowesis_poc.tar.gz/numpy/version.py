
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.2'
version = '1.11.2'
full_version = '1.11.2'
git_revision = 'bb6e3dc30016b89bf154f7d7fce4248e760bd40f'
release = True

if not release:
    version = full_version
